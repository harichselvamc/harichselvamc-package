from .triangle import generate_pascals_triangle
