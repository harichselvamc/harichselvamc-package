# __init__.py

from triangle import generate_pascals_triangle  # or generate_triangle if that's your preferred name

__all__ = ["generate_pascals_triangle"]
